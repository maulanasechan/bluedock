class ProjecetSelectionEntity {
  final String selectionId;
  final String title;
  ProjecetSelectionEntity({required this.selectionId, required this.title});

  Map<String, dynamic> toJson() => {'selectionId': selectionId, 'title': title};

  factory ProjecetSelectionEntity.fromJson(Map<String, dynamic> json) {
    return ProjecetSelectionEntity(
      selectionId: json['selectionId'] as String,
      title: json['title'] as String,
    );
  }

  factory ProjecetSelectionEntity.fromMap(Map<String, dynamic>? map) {
    if (map == null) {
      throw ArgumentError('Selection model: map is null');
    }

    final String selectionId =
        (map['selectionId'] ?? map['selectionId'] ?? '') as String;

    return ProjecetSelectionEntity(
      selectionId: selectionId,
      title: (map['title'] ?? '') as String,
    );
  }
}
